module.exports = {
  local: {
    database: "card",
    username: "root",
    password: "",
    hosting: "localhost",
  },
  host: {
    database: "projec79_cardIdulAdha",
    username: "projec79_cardIdulAdha",
    password: "L!us_20071997",
    hosting: "http://projecttry.my.id/",
  },
};
