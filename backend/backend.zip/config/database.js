const { Sequelize } = require("sequelize");
const setting = require("./db");
const local = setting.local;
const host = setting.host;
const db = new Sequelize(
  local.database || host.database,
  local.username || host.username,
  local.password,
  {
    host: local.hosting || host.hosting,
    dialect: "mysql",
  },
  {
    define: {
      freezeTableName: true,
    },
  }
);
module.exports = db;
