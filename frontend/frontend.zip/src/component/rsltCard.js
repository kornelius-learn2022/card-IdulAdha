import { useState, useEffect } from "react";
import axios from "axios";
import "../css/rsltCard.css";
import Banner from "../component/banner";
const ResultCard = () => {
  const get_key = new URLSearchParams(window.location.search).get("key");
  const [responese, setResponse] = useState([]);
  const [count, setCount] = useState(0);

  const get_data = async (props) => {
    await axios
      .get(
        `https://api.projecttry.my.id/usrMessage?key=${props}`,

        {
          headers: {
            "content-type": "application/json",
          },
        }
      )
      .then((res) => {
        setResponse({
          nama: res.data.nama,
          pesan: res.data.pesan,
        });
      })
      .catch((errr) => {
        console.error("Tidak dapat mengakses data server", errr);
      });
  };
  if (Object.keys(responese).length !== 0) {
    const time = setTimeout(() => {
      setCount(count + 1);
    }, 1000);
    if (count === 3) {
      clearTimeout(time);
    }
  }

  useEffect(() => {
    get_data(get_key);
  }, [get_key]);
  const ShowCard = (res) => {
    return (
      <div id="showCard">
        <p id="resultCard">
          <p id="nama">{res.res.nama}</p>
          <br />
          <p id="say">Mengucapkan</p> <br />
          <p id="pesan">{res.res.pesan}</p>
        </p>
      </div>
    );
  };
  return count === 3 ? <ShowCard res={responese} /> : <Banner />;
};

export default ResultCard;
