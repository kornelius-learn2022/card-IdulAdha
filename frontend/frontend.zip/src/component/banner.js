import "../css/banner.css";
const Banner = () => {
  return (
    <div id="banner">
      <div id="loading">
        <div id="obj"></div>
        <div id="obj"></div>
        <div id="obj"></div>
        <div id="obj"></div>
        <div id="obj"></div>
        <div id="obj"></div>
        <div id="obj"></div>
        <div id="obj"></div>
      </div>
    </div>
  );
};
export default Banner;
